CREATE TABLE `chamado_history` (
	`id` int AUTO_INCREMENT NOT NULL,
	`chamadoId` int NOT NULL,
	`statusAnterior` varchar(30),
	`statusNovo` varchar(30) NOT NULL,
	`observacao` text,
	`alteradoPor` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `chamado_history_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `chamados` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`tipo` enum('preventivo','urgente') NOT NULL,
	`status` enum('aberto','em_analise','equipe_deslocamento','concluido') NOT NULL DEFAULT 'aberto',
	`descricao` text NOT NULL,
	`endereco` text NOT NULL,
	`subprefeitura` varchar(100),
	`latitude` decimal(10,7),
	`longitude` decimal(10,7),
	`fotoUrl` text,
	`fotoUrl2` text,
	`fotoUrl3` text,
	`contatoFiacao` enum('sim','nao') NOT NULL DEFAULT 'nao',
	`gravidade` int NOT NULL DEFAULT 1,
	`urgencia` int NOT NULL DEFAULT 1,
	`tendencia` int NOT NULL DEFAULT 1,
	`gutScore` int NOT NULL DEFAULT 1,
	`observacoesGestor` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`resolvedAt` timestamp,
	CONSTRAINT `chamados_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `phone` varchar(20);