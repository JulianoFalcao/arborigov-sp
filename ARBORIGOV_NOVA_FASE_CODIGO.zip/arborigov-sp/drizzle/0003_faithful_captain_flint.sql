ALTER TABLE `chamados` ADD `iaSaude` varchar(20);--> statement-breakpoint
ALTER TABLE `chamados` ADD `iaRiscoQueda` varchar(20);--> statement-breakpoint
ALTER TABLE `chamados` ADD `iaConfianca` decimal(4,3);--> statement-breakpoint
ALTER TABLE `chamados` ADD `iaAnalisadoEm` timestamp;