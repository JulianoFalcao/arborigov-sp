CREATE TABLE `audit_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`actorUserId` int,
	`action` varchar(80) NOT NULL,
	`resourceType` varchar(50) NOT NULL,
	`resourceId` varchar(64),
	`outcome` enum('success','failure') NOT NULL DEFAULT 'success',
	`requestId` varchar(64),
	`metadata` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `audit_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `chamados` ADD `deletedAt` timestamp;--> statement-breakpoint
ALTER TABLE `chamados` ADD `deletedBy` int;--> statement-breakpoint
ALTER TABLE `chamados` ADD `deletionReason` text;