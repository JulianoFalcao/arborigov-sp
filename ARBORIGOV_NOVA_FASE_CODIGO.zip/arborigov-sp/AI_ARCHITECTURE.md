# Arquitetura de Integração de IA - ArboriGov SP

**Data**: Julho de 2026  
**Versão**: 1.0  
**Status**: Planejamento

---

## 📋 VISÃO GERAL

O ArboriGov SP será aprimorado com funcionalidades de **Inteligência Artificial** para automatizar a análise de imagens de árvores e classificação de risco, agregando valor ao sistema e demonstrando inovação tecnológica.

---

## 🎯 FUNCIONALIDADES DE IA PROPOSTAS

### **1. Análise de Imagens com Vision AI**

**O que faz:**
- Cidadão faz upload de foto da árvore com problema
- IA analisa a imagem e identifica:
  - Saúde geral da árvore
  - Possíveis doenças ou infestações
  - Danos estruturais
  - Risco de queda

**Entrada:**
- Imagem em base64 (já capturada no frontend)

**Saída:**
- Diagnóstico estruturado em JSON:
  ```json
  {
    "saude_geral": "crítica | ruim | regular | boa | excelente",
    "doencas_detectadas": ["ferrugem", "fungo", ...],
    "danos_estruturais": ["galho quebrado", "tronco danificado", ...],
    "risco_queda": "baixo | médio | alto | crítico",
    "confianca": 0.95,
    "recomendacoes": ["poda", "tratamento", "remoção", ...]
  }
  ```

**Implementação:**
- Usar `invokeLLM` com multimodal support (image_url)
- Usar `response_format` com JSON Schema para estruturar resposta
- Modelo: `gemini-2.5-flash` (já configurado)

---

### **2. Classificação de Risco Automática**

**O que faz:**
- Baseado na análise de imagem + dados do chamado
- IA calcula automaticamente:
  - **Gravidade** (1-5): Quanto a árvore está danificada
  - **Urgência** (1-5): Quão rápido precisa de intervenção
  - **Tendência** (1-5): Como o problema evoluirá

**Entrada:**
- Diagnóstico da imagem (do passo 1)
- Dados do chamado: tipo, endereço, contato com fiação, etc.

**Saída:**
- Scores estruturados:
  ```json
  {
    "gravidade": 4,
    "urgencia": 5,
    "tendencia": 3,
    "gut_score": 60,
    "tipo_intervencao_sugerido": "remoção | poda | tratamento",
    "justificativa": "..."
  }
  ```

**Implementação:**
- Usar `invokeLLM` com prompt estruturado
- Usar `response_format` com JSON Schema
- Integrar no endpoint `chamado.create`

---

### **3. Recomendação de Ações**

**O que faz:**
- IA sugere melhor tipo de intervenção
- Estima custo e tempo necessário
- Prioriza por urgência

**Entrada:**
- Classificação de risco (do passo 2)
- Tipo de árvore (se disponível)

**Saída:**
- Recomendações estruturadas:
  ```json
  {
    "intervencao_recomendada": "remoção",
    "custo_estimado": "R$ 2.000 - R$ 3.000",
    "tempo_estimado": "2-3 dias",
    "equipe_necessaria": "3 pessoas",
    "equipamento": ["motosserra", "corda", "plataforma"],
    "observacoes": "..."
  }
  ```

**Implementação:**
- Usar `invokeLLM` com contexto histórico
- Usar `response_format` com JSON Schema

---

## 🏗️ ARQUITETURA TÉCNICA

### **Stack Existente**
- **Backend**: Express + tRPC
- **Frontend**: React 19 + Tailwind
- **Database**: MySQL (TiDB)
- **LLM**: Forge API (Gemini 2.5 Flash)
- **Storage**: AWS S3

### **Fluxo de Integração**

```
┌─────────────────────────────────────────────────────────────┐
│ FRONTEND (React)                                            │
│ ┌──────────────────────────────────────────────────────┐   │
│ │ CitizenDashboard.tsx                                │   │
│ │ - Upload foto (base64)                              │   │
│ │ - Mostrar análise de IA                             │   │
│ │ - Mostrar scores sugeridos                          │   │
│ └──────────────────────────────────────────────────────┘   │
└──────────────────────┬──────────────────────────────────────┘
                       │ tRPC call
                       ▼
┌─────────────────────────────────────────────────────────────┐
│ BACKEND (tRPC Router)                                       │
│ ┌──────────────────────────────────────────────────────┐   │
│ │ chamado.analyzeImage (novo)                         │   │
│ │ - Recebe: fotoBase64                                │   │
│ │ - Retorna: diagnóstico IA                           │   │
│ └──────────────────────────────────────────────────────┘   │
│ ┌──────────────────────────────────────────────────────┐   │
│ │ chamado.create (modificado)                         │   │
│ │ - Recebe: dados + análise IA                        │   │
│ │ - Calcula: gravidade, urgência, tendência com IA   │   │
│ │ - Salva: chamado + diagnóstico IA                   │   │
│ └──────────────────────────────────────────────────────┘   │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│ LLM SERVICE (Forge API)                                     │
│ ┌──────────────────────────────────────────────────────┐   │
│ │ invokeLLM()                                         │   │
│ │ - Modelo: gemini-2.5-flash                         │   │
│ │ - Input: imagem + contexto                         │   │
│ │ - Output: JSON estruturado                         │   │
│ └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

---

## 📊 MUDANÇAS NO BANCO DE DADOS

### **Nova Tabela: `chamado_ia_analysis`**

```sql
CREATE TABLE chamado_ia_analysis (
  id INT PRIMARY KEY AUTO_INCREMENT,
  chamadoId INT NOT NULL,
  
  -- Análise de Imagem
  saude_geral VARCHAR(20),
  doencas_detectadas JSON,
  danos_estruturais JSON,
  risco_queda VARCHAR(20),
  confianca_diagnostico DECIMAL(3,2),
  
  -- Classificação de Risco
  gravidade_ia INT,
  urgencia_ia INT,
  tendencia_ia INT,
  
  -- Recomendação
  intervencao_recomendada VARCHAR(100),
  custo_estimado VARCHAR(100),
  tempo_estimado VARCHAR(100),
  
  -- Auditoria
  createdAt TIMESTAMP DEFAULT NOW(),
  updatedAt TIMESTAMP DEFAULT NOW() ON UPDATE NOW(),
  
  FOREIGN KEY (chamadoId) REFERENCES chamados(id)
);
```

---

## 🔌 ENDPOINTS NOVOS (tRPC)

### **1. `chamado.analyzeImage`**

**Input:**
```typescript
{
  fotoBase64: string;  // Imagem em base64
}
```

**Output:**
```typescript
{
  saude_geral: "crítica" | "ruim" | "regular" | "boa" | "excelente";
  doencas_detectadas: string[];
  danos_estruturais: string[];
  risco_queda: "baixo" | "médio" | "alto" | "crítico";
  confianca: number;
  recomendacoes: string[];
}
```

**Implementação:**
- Usar `invokeLLM` com multimodal
- Não salva no banco (apenas retorna)
- Chamado antes de `chamado.create`

---

### **2. `chamado.create` (modificado)**

**Mudanças:**
- Aceita novo parâmetro: `iaAnalysis?: object`
- Se `iaAnalysis` fornecido, usa scores de IA
- Caso contrário, usa heurística atual
- Salva análise de IA em `chamado_ia_analysis`

---

## 🧪 TESTES PROPOSTOS

### **1. Teste de Análise de Imagem**
```typescript
test("analyzeImage retorna diagnóstico estruturado", async () => {
  const fotoBase64 = "data:image/jpeg;base64,...";
  const result = await trpc.chamado.analyzeImage.mutate({ fotoBase64 });
  
  expect(result).toHaveProperty("saude_geral");
  expect(result).toHaveProperty("risco_queda");
  expect(result.confianca).toBeGreaterThan(0);
});
```

### **2. Teste de Criação com IA**
```typescript
test("create com iaAnalysis usa scores de IA", async () => {
  const chamado = await trpc.chamado.create.mutate({
    tipo: "urgente",
    descricao: "Árvore com risco de queda",
    endereco: "Rua X, 123",
    iaAnalysis: {
      gravidade_ia: 5,
      urgencia_ia: 5,
      tendencia_ia: 4
    }
  });
  
  expect(chamado.gravidade).toBe(5);
  expect(chamado.gutScore).toBe(5 * 5 * 4);
});
```

---

## 📱 UX/UI CHANGES

### **CitizenDashboard.tsx**

**Novo fluxo:**
1. Cidadão faz upload de foto
2. Clica em "Analisar com IA" (novo botão)
3. Sistema mostra:
   - Diagnóstico da árvore
   - Scores de risco sugeridos
   - Recomendações
4. Cidadão pode aceitar ou editar scores
5. Submete o chamado

---

## 🚀 PLANO DE IMPLEMENTAÇÃO

### **Sprint 1: Análise de Imagem**
- [ ] Criar endpoint `chamado.analyzeImage`
- [ ] Integrar `invokeLLM` com multimodal
- [ ] Testar com imagens reais
- [ ] Adicionar UI no frontend

### **Sprint 2: Classificação de Risco**
- [ ] Criar lógica de classificação com IA
- [ ] Modificar `chamado.create`
- [ ] Criar tabela `chamado_ia_analysis`
- [ ] Testar integração

### **Sprint 3: Recomendações**
- [ ] Adicionar recomendações de ação
- [ ] Integrar com dashboard do gestor
- [ ] Testes completos

### **Sprint 4: Entrega**
- [ ] Documentação
- [ ] Vídeo pitch
- [ ] Slides
- [ ] Push para GitHub

---

## ✅ CHECKLIST

- [ ] Arquitetura aprovada
- [ ] Endpoints definidos
- [ ] Schema do banco definido
- [ ] Testes planejados
- [ ] UI/UX definida
- [ ] Implementação iniciada

---

**Próximo Passo**: Iniciar Sprint 1 - Implementar `chamado.analyzeImage`
