# ArboriGov SP

O **ArboriGov SP** é uma solução GovTech para registrar, classificar e acompanhar solicitações de poda e remoção de árvores em São Paulo. A aplicação conecta cidadãos e gestores públicos por meio de uma interface React, serviços tRPC, uma API RESTful versionada, banco MySQL/TiDB, análise visual por IA e relatórios estatísticos.

**Aplicação publicada:** [https://arborigov-bywwkv5n.manus.space](https://arborigov-bywwkv5n.manus.space)

## Funcionalidades

| Área | Funcionalidades |
|---|---|
| Cidadão | Cadastro de chamado, até três fotos, geolocalização, triagem por IA e acompanhamento de status |
| Gestor | Fila priorizada por GUT, atualização de status e prioridade, gráficos e interpretação estatística |
| Governança | Perfis de acesso, autorização por proprietário, exclusão lógica e trilha de auditoria |
| Integração | API RESTful `/api/rest/v1` e API interna tRPC `/api/trpc` |
| Qualidade | Validação Zod, erros padronizados, OpenAPI e 51 testes Vitest |

## Arquitetura

```text
React 19 + Tailwind CSS 4
          │
          ├── tRPC ───────────────┐
          └── REST /api/rest/v1 ──┤
                                  ▼
                         Express + Zod
                          │      │
                          │      └── IA multimodal
                          ▼
                    Drizzle ORM
                          ▼
                      MySQL/TiDB
```

O tRPC é utilizado pela interface principal para preservar tipagem ponta a ponta. A API RESTful compartilha os mesmos serviços de domínio e existe para interoperabilidade, integração externa e demonstração acadêmica de métodos HTTP e status codes.

## Tecnologias

| Camada | Tecnologias |
|---|---|
| Front-end | React 19, TypeScript, Tailwind CSS 4, shadcn/ui, Recharts, Wouter |
| Back-end | Node.js, Express 4, tRPC 11, Zod |
| Dados | MySQL/TiDB, Drizzle ORM |
| IA | Modelo multimodal acessado pelo serviço integrado do ambiente |
| Testes | Vitest |
| Autenticação | OAuth e cookie de sessão seguro |

## Pré-requisitos

O projeto requer Node.js 22 ou superior e pnpm. As variáveis de ambiente de banco, autenticação, armazenamento e IA são fornecidas pelo ambiente de hospedagem; não devem ser inseridas no código nem versionadas.

## Instalação e execução

```bash
pnpm install
pnpm run dev
```

A aplicação utiliza a porta definida em `PORT`; quando ausente, tenta iniciar em `3000` e procura outra porta disponível se necessário.

### Verificações

```bash
pnpm run check
pnpm test
pnpm run build
```

## Banco de dados

O schema está em `drizzle/schema.ts`. Para gerar uma migração local:

```bash
pnpm drizzle-kit generate
```

As tabelas de domínio são `chamados`, `chamado_history` e `audit_logs`. Fotos são armazenadas em storage; o banco mantém somente referências por URL.

### Nova fase: IA verificável e prioridade algorítmica

O resultado da análise visual recebe uma atestação HMAC-SHA256 vinculada ao usuário e ao conteúdo da primeira foto, válida por 15 minutos. O cadastro valida essa atestação antes de persistir saúde, risco de queda, confiança informada pelo modelo e instante da análise. Confiança inferior a 60% não modifica o GUT inicial; esse limiar é heurístico, não uma acurácia calibrada. A alteração do schema está na migração `drizzle/0003_faithful_captain_flint.sql` e exige execução no banco do ambiente de implantação.

Gestores podem consultar `stats.priorityTop` via tRPC para obter os cinco chamados pendentes mais prioritários. A seleção usa um min-heap binário (`server/priority.ts`), desempata por antiguidade e menor ID e não retorna dados pessoais na fila. O painel do gestor mostra a síntese da IA e a prioridade calculada; a vistoria técnica permanece necessária.

As respostas acadêmicas desta fase estão em [`docs/NOVA_FASE_RELATORIO.md`](docs/NOVA_FASE_RELATORIO.md); consultas reproduzíveis em [`docs/NOVA_FASE_SQL.sql`](docs/NOVA_FASE_SQL.sql). Dados estatísticos citados são de homologação, não indicadores oficiais. Ainda não existem sensores IoT conectados.

## API RESTful

A especificação está em [`docs/openapi.yaml`](docs/openapi.yaml). Todas as rotas, exceto o health check, exigem sessão válida.

| Método | Rota | Acesso | Resultado |
|---|---|---|---|
| GET | `/api/rest/v1/health` | Público | Saúde do serviço |
| GET | `/api/rest/v1/chamados` | Autenticado | Lista conforme o perfil |
| POST | `/api/rest/v1/chamados` | Autenticado | Cria chamado |
| GET | `/api/rest/v1/chamados/:id` | Dono ou gestor | Consulta detalhe |
| PATCH | `/api/rest/v1/chamados/:id` | Dono autorizado ou gestor | Atualiza dados |
| DELETE | `/api/rest/v1/chamados/:id` | Dono autorizado ou gestor | Exclusão lógica |
| PATCH | `/api/rest/v1/chamados/:id/status` | Gestor | Atualiza status |
| PATCH | `/api/rest/v1/chamados/:id/gut` | Gestor | Atualiza GUT |
| GET | `/api/rest/v1/chamados/:id/historico` | Dono ou gestor | Histórico funcional |
| GET | `/api/rest/v1/relatorios/resumo` | Gestor | Estatísticas descritivas |
| GET | `/api/rest/v1/auditoria` | Gestor | Trilha de auditoria |

### Exemplo de erro

```json
{
  "error": {
    "code": "FORBIDDEN",
    "message": "Acesso negado a este chamado"
  },
  "requestId": "req_01H..."
}
```

## Perfis e credenciais de demonstração

Não existem senhas estáticas no repositório. O acesso é realizado pelo fluxo OAuth da plataforma.

| Perfil | Como acessar |
|---|---|
| Cidadão | Entrar com uma conta válida; novos usuários recebem o perfil `user` |
| Gestor | O proprietário configurado em `OWNER_OPEN_ID` recebe o perfil `admin` |

## Segurança e privacidade

O servidor verifica autenticação e autorização em cada operação protegida. Cidadãos acessam somente os próprios chamados; gestores acessam funções administrativas. A API retorna DTOs diferentes por perfil, evita expor campos internos, limita imagens a JPG, PNG ou WebP com até 5 MB e registra operações críticas em `audit_logs` sem armazenar tokens, cookies ou arquivos brutos.

## Estatística e estruturas de dados

O relatório calcula total, taxa de resolução, média, mediana e desvio-padrão do GUT, além do tempo médio de resolução. A fila operacional é uma fila de prioridade lógica: maior GUT primeiro e, em empates, chamado mais antigo primeiro. Listas representam chamados e eventos; o histórico é uma sequência temporal imutável de alterações de status.

## Estrutura do projeto

```text
client/src/             Interface React
server/rest.ts          API RESTful
server/routers.ts       API tRPC
server/db.ts            Acesso a dados
server/statistics.ts    Estatísticas descritivas
server/risk.ts          Classificação GUT
server/ai-attestation.ts Atestação da IA vinculada à foto
server/priority.ts      Seleção top-k por heap binário
drizzle/schema.ts       Modelo relacional
docs/openapi.yaml       Contrato OpenAPI
docs/                   Documentação acadêmica
```

## Autor

**Juliano de Oliveira Falcão** — RM 565907 — São Paulo, SP.
