# ArboriGov SP — IA, dados e eficiência

**Nova fase do HackGov | Relatório técnico das Partes 1 a 4**  
**Autor:** Juliano de Oliveira Falcão · **RM:** 565907  
**Local:** São Paulo, SP · **Modalidade:** trabalho individual  
**Data da medição:** 05 de outubro de 2026

> **Escopo e honestidade dos dados.** Os números deste relatório provêm do banco de homologação do próprio projeto na data indicada. Eles não constituem estimativas sobre a arborização ou a demanda real da Prefeitura de São Paulo. O vídeo e a entrega da fase anterior foram concluídos pelo autor; este arquivo refere-se exclusivamente à nova fase. O upload à FIAP ON e a avaliação do professor não são atestados aqui.

## Resumo executivo

O ArboriGov recebe chamados de poda/remoção, fotos, localização e contato com fiação; registra histórico e auditoria, aplica a matriz GUT e mostra painéis gerenciais. A triagem visual por IA já existia. Nesta etapa, ela foi fortalecida: o servidor agora **assina o resultado**, liga-o à foto e ao cidadão por 15 minutos, **persiste uma síntese** e impede que uma estimativa de confiança inferior a 60% altere automaticamente o GUT inicial. Em paralelo, uma **fila top-5 por heap binário** ajuda o gestor a focar os casos pendentes. Consultas SQL reais usam `GROUP BY`, agregações, CTE, subconsulta e `DENSE_RANK()`.

**Evidência de validação:** `pnpm run check`, `pnpm test` (**51 testes em oito arquivos**) e `pnpm run build` concluídos. A única advertência de build é tamanho do bundle, sem erro de compilação. Os 77 chamados preexistentes ainda têm `iaAnalisadoEm = NULL`; **não há resultados reais dessa nova persistência a alegar**. A seleção top-5 foi validada por testes unitários, e os dados do banco foram medidos por consultas de leitura.

## Parte 1 — Versão atual e evoluções desde a última entrega

### Base herdada da etapa anterior

A versão anterior já incluía interface React para cidadão e gestor, cadastro de chamado com até três imagens, geolocalização opcional, cálculo GUT, análise multimodal de imagem sob demanda, API REST `/api/rest/v1`, tRPC para o front-end, autenticação OAuth, autorização por perfil/propriedade, exclusão lógica, auditoria e estatísticas. Havia 43 testes automatizados aprovados. A aplicação permanece disponível em [arborigov-bywwkv5n.manus.space](https://arborigov-bywwkv5n.manus.space).

### Mudanças efetivamente realizadas nesta fase

| Camada | Evolução | Evidência no projeto |
|---|---|---|
| Backend/IA | Validação estruturada do diagnóstico; token HMAC-SHA256 emitido pelo servidor, vinculado ao usuário e ao SHA-256 da imagem, com validade de 15 min | `server/ai-attestation.ts`, `server/routers.ts` |
| Segurança/decisão | O cadastro rejeita token alterado, expirado, de outro usuário ou de outra foto; sem análise atestada, o GUT é calculado apenas das entradas convencionais; abaixo de 60% a IA não altera o GUT | `server/routers.ts`, `server/ai-attestation.test.ts` |
| Banco de dados | Quatro colunas opcionais: `iaSaude`, `iaRiscoQueda`, `iaConfianca`, `iaAnalisadoEm`; migração incremental sem remoção de registros | `drizzle/schema.ts`, `drizzle/0003_faithful_captain_flint.sql` |
| Front-end | Cidadão recebe aviso de baixa confiança; gestor visualiza síntese, confiança, horário e necessidade de vistoria | `CitizenDashboard.tsx`, `ManagerDashboard.tsx` |
| Algoritmo | `topPriority(items, 5)` usa min-heap e devolve uma fila resumida de pendentes; rota administrativa `stats.priorityTop` | `server/priority.ts`, `server/priority.test.ts`, painel do gestor |
| Qualidade | Oito testes novos elevaram a suíte de 43 a 51; tipagem e build aprovados | Vitest, TypeScript, Vite/esbuild em 05/10/2026 |

**Arquitetura de integração:** navegador → `chamado.analyzeImage` (servidor → modelo multimodal → validação/assinatura) → `chamado.create` (validação de vínculo → GUT → banco/histórico/auditoria) → `stats.priorityTop` (consulta agregada → heap) → painel do gestor. A API REST da etapa anterior permanece disponível; os novos fluxos de IA e fila foram integrados pelo tRPC tipado, já utilizado no front-end.

## Parte 2 — Revisão do Product Backlog

A priorização considera valor para a decisão pública, segurança, esforço e qualidade dos dados. **Concluído** indica funcionalidade implementada nesta fase; **planejado** não deve ser descrito como entregue.

| ID | Prioridade | User story | Integração | Estado |
|---|---|---|---|---|
| US-21 | Alta | Como cidadão, quero analisar minha foto antes de abrir o chamado e enviar somente um resultado associado à foto para evitar diagnósticos forjados. | Front-end, backend, IA | Concluído |
| US-22 | Alta | Como gestor, quero consultar risco, saúde, confiança e horário da triagem para decidir se devo vistoriar o local. | Banco, backend, front-end | Concluído |
| US-23 | Alta | Como gestor, quero ver os cinco chamados pendentes mais críticos sem carregar dados pessoais na fila para organizar a atuação. | Banco, algoritmo, API, front-end | Concluído |
| US-24 | Alta | Como analista, quero comparar regiões com agregações e ranking SQL para identificar prioridades e lacunas cadastrais. | Banco, SQL, relatório | Concluído como análise reproduzível; não é endpoint novo |
| US-25 | Média | Como gestor, quero filtrar o histórico de triagens por período e taxa de revisão para acompanhar qualidade do modelo. | Banco, API, front-end | Planejado |
| US-26 | Média | Como administrador, quero paginação e índices nos filtros de chamados para sustentar maior volume sem carregar a base completa. | Banco, backend, front-end | Planejado |
| US-27 | Média | Como equipe de campo, quero registrar a conclusão técnica da vistoria para comparar hipótese de IA com diagnóstico humano. | Front-end, backend, banco | Planejado |
| US-28 | Baixa | Como gestor, quero receber leituras de sensores IoT autenticados de inclinação/umidade quando houver infraestrutura real para validar sinais adicionais. | Dispositivo, ingestão, banco | Estudo futuro; nenhum sensor conectado |

### Critérios de aceitação prioritários

1. **US-21:** foto em JPG/PNG/WebP de até 5 MB; operação protegida; retorno estruturado validado; atestação assinada expira após 15 minutos e só funciona com o mesmo `userId` e o mesmo conteúdo de imagem. Sem foto, a criação com atestação deve falhar. Alterar token, foto ou usuário deve produzir erro controlado, sem persistir resultado forjado.
2. **US-22:** o cadastro salva apenas saúde, risco, confiança e instante da análise; campos são opcionais para chamados legados; a tela do gestor mostra dados apenas quando presentes; abaixo de 60% aparece aviso de que a IA não influenciou o GUT. A vistoria humana continua necessária, inclusive com confiança alta.
3. **US-23:** só perfil administrador acessa `stats.priorityTop`; somente chamados não concluídos e não excluídos logicamente concorrem; ordenar por GUT decrescente, depois mais antigo e menor ID; devolver no máximo cinco registros sem nome, endereço, foto ou coordenadas; atualizar a fila após alteração de status/GUT.
4. **US-24:** consultas executáveis no banco real, sempre com `deletedAt IS NULL`; incluir totais e médias regionais e pelo menos uma CTE/subconsulta/função de janela; resultados documentados com data, fonte e ressalvas de completude, sem dados pessoais.

**Próximos critérios para o backlog:** US-25 requer feedback de vistoria humana e amostra suficiente antes de avaliar qualidade; US-26 requer medir latência/volume e definir índices com `EXPLAIN`; US-28 depende de hardware, autenticação, calibração, conectividade e governança de retenção. Nenhum desses itens foi simulado como se estivesse em produção.

## Parte 3 — Inteligência Artificial e IoT

### Problema e tecnologia escolhida

Fotografias podem ajudar a identificar sinais visuais de dano estrutural, doença e risco de queda, mas um parecer textual produzido por modelo generativo pode errar, omitir contexto ou ser adulterado no navegador. Como **a análise multimodal por IA já estava implementada e rodando**, a evolução pertinente é tornar o uso do resultado **rastreável, limitado e verificável**. Optou-se por continuar com o modelo multimodal de visão acessado apenas no backend via `invokeLLM`, com saída JSON estruturada; IoT não é necessária para esta melhoria, porque não há sensores reais instalados, mantidos ou calibrados.

### Dados, integração e fluxo

1. O cidadão informa tipo, descrição, endereço, subprefeitura opcional, contato com fiação e uma foto; o navegador chama a análise sob demanda. A imagem é enviada ao serviço de IA pelo backend, não com chave no cliente.
2. O servidor exige valores enumerados para saúde/risco, confiança numérica entre 0 e 1 e listas limitadas de recomendações/danos. Emite uma atestação HMAC contendo usuário, hash SHA-256 do conteúdo da imagem, avaliação, instante de análise e validade de 15 minutos. A assinatura impede alterações pelo cliente; o token é evidência de proveniência **do fluxo da aplicação**, não certificação científica do diagnóstico.
3. No envio do chamado, o backend verifica assinatura, expiração, usuário e mesma primeira foto. Persiste **quatro campos resumidos**, além da URL da foto no armazenamento já existente; não guarda o token nem o texto integral da resposta do modelo na tabela. Cria evento de auditoria informando se a IA foi usada e se influenciou o GUT, sem copiar imagem ou parecer integral para o log.
4. Caso a confiança **informada pelo próprio modelo** seja menor que 0,60, a pontuação GUT inicial usa as regras convencionais; caso contrário, utiliza os sinais da IA conforme `calculateGutScores`. A decisão final continua com o gestor. A prioridade top-5 usa GUT e idade, independentemente da origem do escore.
5. No painel, o gestor vê a síntese da IA e consegue rever GUT/status; chamados antigos continuam válidos com campos de IA nulos.

**Exemplo conceitual, não resultado de produção:** uma imagem de galho comprometido pode levar o modelo a sugerir risco alto; o servidor vincula a sugestão à foto, mas o gestor precisa confirmar in loco. A execução real verificada nesta fase é a integração e os testes; no corte SQL de 05/10/2026, **0 dos 77 registros legados tinham nova triagem persistida**. Não foi criado chamado artificial para inflar evidência.

### Benefícios e limitações

| Benefício | Limite e mitigação |
|---|---|
| Apoio à triagem e persistência de evidência resumida | Imagens podem não revelar raízes, inclinação dinâmica ou condições internas; vistoria por profissional permanece mandatória. |
| Vínculo criptográfico entre análise, foto e cidadão | Token é reutilizável pelo mesmo usuário enquanto válido; não equivale a prova imutável nem impede foto enganosa. |
| Menor exposição: dados sintéticos de auditoria, sem imagem bruta em logs | Fotos e endereço continuam dados potencialmente pessoais; exigir controle de acesso, retenção e revisão de permissões. |
| Fallback quando confiança declarada é baixa | `0,60` é um limiar heurístico de segurança operacional, **não calibrado estatisticamente**; a confiança do modelo não é probabilidade validada de acerto. |
| Sem dependência de hardware | Não captura sinais contínuos; IoT futura depende de sensores, bateria/rede, manutenção, autenticidade e protocolos de segurança. |

O [NIST AI RMF 1.0](https://www.nist.gov/publications/artificial-intelligence-risk-management-framework-ai-rmf-10) oferece um referencial voluntário para gerenciar riscos de sistemas de IA; a implantação deste protótipo **não constitui certificação de conformidade ao NIST**. Para uso real em poder público, são necessários avaliação de acurácia com laudos humanos, monitoramento de viés, política de retenção e gestão de incidentes.

## Parte 4 — Análise e eficiência dos dados

### 4.1 SQL avançado sobre o banco do projeto

As consultas integrais estão em `CONSULTAS_SQL.sql` e foram executadas via conexão do projeto. Nenhuma delas retorna nome, telefone, descrição, endereço ou foto. Em todas, `deletedAt IS NULL` retira registros excluídos logicamente.

**Consulta A — agrupamentos e métricas:**

```sql
SELECT COALESCE(subprefeitura, 'Não informada') AS regiao,
       COUNT(*) AS total,
       SUM(CASE WHEN tipo = 'urgente' THEN 1 ELSE 0 END) AS urgentes,
       SUM(CASE WHEN status = 'concluido' THEN 1 ELSE 0 END) AS concluidos,
       ROUND(AVG(gutScore), 2) AS gut_medio
FROM chamados
WHERE deletedAt IS NULL
GROUP BY COALESCE(subprefeitura, 'Não informada')
ORDER BY total DESC, regiao;
```

**Resultados observados em 05/10/2026 — banco de homologação:**

| Região registrada | Total | Urgentes | Concluídos | GUT médio |
|---|---:|---:|---:|---:|
| Não informada | 60 | 0 | 0 | 17,47 |
| Centro | 5 | 0 | 0 | 100,00 |
| Pinheiros | 5 | 5 | 1 | 75,00 |
| Campo Limpo | 2 | 1 | 0 | 56,00 |
| Cidade Tiradentes | 2 | 2 | 0 | 72,50 |
| Butantã | 1 | 0 | 0 | 18,00 |
| Ipiranga | 1 | 0 | 0 | 30,00 |
| Santo Amaro | 1 | 0 | 0 | 18,00 |

**Consulta B — CTE, subconsulta e função de janela:**

```sql
WITH regional AS (
  SELECT subprefeitura AS regiao, COUNT(*) AS total,
         ROUND(AVG(gutScore), 2) AS gut_medio,
         SUM(CASE WHEN tipo = 'urgente' THEN 1 ELSE 0 END) AS urgentes
  FROM chamados
  WHERE deletedAt IS NULL AND subprefeitura IS NOT NULL
  GROUP BY subprefeitura
)
SELECT regiao, total, urgentes, gut_medio,
       DENSE_RANK() OVER (ORDER BY gut_medio DESC) AS posicao_risco
FROM regional
WHERE gut_medio >= (
  SELECT AVG(gutScore) FROM chamados
  WHERE deletedAt IS NULL AND subprefeitura IS NOT NULL
)
ORDER BY posicao_risco, regiao;
```

| Posição | Região | Total | Urgentes | GUT médio |
|---:|---|---:|---:|---:|
| 1 | Centro | 5 | 0 | 100,00 |
| 2 | Pinheiros | 5 | 5 | 75,00 |
| 3 | Cidade Tiradentes | 2 | 2 | 72,50 |

A CTE calcula indicadores por região; a subconsulta define a referência de GUT médio dos registros com região informada; `DENSE_RANK() OVER (...)` cria uma classificação sem saltar posições em empates, conforme o [manual do MySQL](https://dev.mysql.com/doc/refman/8.4/en/window-function-descriptions.html). O filtro ocorre antes do ranking, portanto as posições classificam **somente as regiões acima da referência**, não todas as regiões do banco. O resultado indica onde investigar primeiro **nesta amostra de homologação**, não um ranking municipal validado.

**Consulta C — qualidade da base:** total **77**, urgentes **8**, concluídos **1**, GUT médio **29,17**, registros sem subprefeitura **60 (77,9%)**, chamados com a nova evidência de IA **0**. A taxa de ausência regional é a principal limitação para qualquer inferência espacial. O valor `Centro` não corresponde a uma das 32 opções do formulário atual, evidenciando registros históricos/entrada inconsistente; recomenda-se normalizar região e validar a proveniência antes de comparações oficiais. Sem dados de produção e representatividade, não se extrapolam esses achados para São Paulo.

![GUT médio por região informada e completude regional; números do banco de homologação](GRAFICO_REGIONAIS.png)

### 4.2 Estruturas de dados, ordenação e complexidade

**Situação:** gestores precisam extrair poucos casos críticos de muitos chamados sem ordenar integralmente todos no servidor. A busca deve excluir concluídos e ordená-los por maior GUT; em empate, ocorre primeiro o mais antigo; persistindo empate, o menor ID.

**Solução implementada:** `server/priority.ts` mantém um **min-heap binário** limitado a `k = 5`. O elemento menos prioritário entre os selecionados fica na raiz. Para cada chamado pendente, insere-o se houver vaga; com heap cheio, substitui a raiz somente se o novo chamado for melhor. Ao final, ordena **apenas os k escolhidos** para apresentação. A consulta de origem já ignora excluídos logicamente; a rota `stats.priorityTop` é restrita a admin, devolve somente ID, GUT, status e subprefeitura e é consumida no painel.

**Aplicação medida no banco de homologação (05/10/2026):** ao executar `getChamadosForStatistics()` e `topPriority(rows, 5)` sobre 77 registros, o retorno resumido foi: ID 150001 (GUT 125; Cidade Tiradentes; equipe em deslocamento), ID 2 (GUT 100; Centro; aberto), ID 30002 (GUT 100; Centro; aberto), ID 180003 (GUT 100; Centro; aberto) e ID 210003 (GUT 100; Centro; aberto). Os empates em GUT 100 foram resolvidos pela antiguidade registrada; a execução não consultou nome ou endereço para selecionar os casos. Esses identificadores são da base de homologação, não protocolos municipais reais.

```text
para cada chamado c não concluído:
  se heap contém menos que k: inserir c e subir no heap
  senão, se c é melhor que a raiz: substituir raiz e descer no heap
ordenar os no máximo k selecionados e devolver
```

Para `n` itens de entrada e `k` posições, percorre-se a lista em **O(n)** e cada ajuste custa **O(log k)**; o fechamento ordena em **O(k log k)**. Portanto: **O(n log k + k log k) tempo** e **O(k) memória adicional** (sem contar a coleção recebida do banco). Se `k = 5` for constante, a seleção é linear em `n`. Ordenar toda a coleção na aplicação seria **O(n log n)** e guardaria mais dados em memória. Os testes verificam top-k, desempate, remoção dos concluídos, fila vazia e limites inválidos.

**Limite de escala:** a implementação atual ainda materializa os `n` registros resumidos vindos do banco antes de aplicar o heap. Em bases realmente grandes, paginar/filtrar na consulta e criar índices adequados exigirá medir planos com `EXPLAIN`; portanto **não se afirma que o sistema já seja Big Data**. A evolução futura pode combinar índice em `deletedAt/status/gutScore/createdAt` e processamento incremental, sem introduzir infraestrutura distribuída desnecessária para uma amostra de 77 registros.

## Conclusão e próximos passos

Nesta fase, o sistema ganhou proteção de proveniência da IA, persistência mínima da avaliação, limiar de revisão, fila de prioridade e análise SQL avançada baseada em dados reais de homologação. **Não há sensores IoT instalados**, nem avaliação estatística de acurácia do modelo, nem garantia de prontidão para operação pública. O próximo ciclo deve normalizar subprefeituras, colher avaliações humanas verificadas, medir acurácia/calibração por subgrupo e observar desempenho antes de selecionar infraestrutura de ingestão em larga escala.

**Arquivos/evidências:** `docs/NOVA_FASE_SQL.sql`, `server/ai-attestation.ts`, `server/priority.ts`, testes novos, migração `0003_faithful_captain_flint.sql`, `RESULTADOS_REGIONAIS.csv` e `GRAFICO_REGIONAIS.png`. Repositório da etapa anterior: [JulianoFalcao/arborigov-sp](https://github.com/JulianoFalcao/arborigov-sp); a versão **desta fase** é fornecida no pacote de código separado, pois a publicação no GitHub não foi comprovada neste relatório.

### Referências

- NATIONAL INSTITUTE OF STANDARDS AND TECHNOLOGY. [Artificial Intelligence Risk Management Framework (AI RMF 1.0)](https://www.nist.gov/publications/artificial-intelligence-risk-management-framework-ai-rmf-10). NIST AI 100-1, 2023. Consulta em 05 out. 2026.
- ORACLE. [MySQL 8.4 Reference Manual — Window Function Descriptions](https://dev.mysql.com/doc/refman/8.4/en/window-function-descriptions.html). Consulta em 05 out. 2026.
- ARBORIGOV SP. Esquema, código, testes e consultas executadas no ambiente de homologação, 05 out. 2026. Fonte primária dos indicadores e das descrições de implementação.
