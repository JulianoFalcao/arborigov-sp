-- ArboriGov SP | Nova fase | execução no banco de homologação em 05/10/2026.
-- Não retorna nome, endereço, coordenadas, foto ou identificadores de usuários.
-- Chamados excluídos logicamente ficam fora de todas as métricas.

-- Consulta 1: distribuição regional, volume, urgência, resolução e GUT.
SELECT COALESCE(subprefeitura, 'Não informada') AS regiao,
       COUNT(*) AS total,
       SUM(CASE WHEN tipo = 'urgente' THEN 1 ELSE 0 END) AS urgentes,
       SUM(CASE WHEN status = 'concluido' THEN 1 ELSE 0 END) AS concluidos,
       ROUND(AVG(gutScore), 2) AS gut_medio
FROM chamados
WHERE deletedAt IS NULL
GROUP BY COALESCE(subprefeitura, 'Não informada')
ORDER BY total DESC, regiao ASC;

-- Consulta 2: CTE, subconsulta escalar e função de janela DENSE_RANK.
-- A comparação exclui chamados sem subprefeitura, para reduzir viés de ausência de dados.
WITH regional AS (
  SELECT subprefeitura AS regiao,
         COUNT(*) AS total,
         ROUND(AVG(gutScore), 2) AS gut_medio,
         SUM(CASE WHEN tipo = 'urgente' THEN 1 ELSE 0 END) AS urgentes
  FROM chamados
  WHERE deletedAt IS NULL AND subprefeitura IS NOT NULL
  GROUP BY subprefeitura
)
SELECT regiao, total, urgentes, gut_medio,
       DENSE_RANK() OVER (ORDER BY gut_medio DESC) AS posicao_risco
FROM regional
WHERE gut_medio >= (
  SELECT AVG(gutScore) FROM chamados
  WHERE deletedAt IS NULL AND subprefeitura IS NOT NULL
)
ORDER BY posicao_risco, regiao;

-- Consulta 3: panorama de qualidade da base e adoção da nova evidência de IA.
SELECT COUNT(*) AS total,
       SUM(CASE WHEN tipo = 'urgente' THEN 1 ELSE 0 END) AS urgentes,
       SUM(CASE WHEN status = 'concluido' THEN 1 ELSE 0 END) AS concluidos,
       SUM(CASE WHEN subprefeitura IS NULL THEN 1 ELSE 0 END) AS sem_regiao,
       SUM(CASE WHEN iaAnalisadoEm IS NOT NULL THEN 1 ELSE 0 END) AS com_triagem_ia,
       ROUND(AVG(gutScore), 2) AS gut_medio
FROM chamados
WHERE deletedAt IS NULL;
