export type RestError = {
  error: { code: string; message: string; details?: unknown };
  requestId?: string;
};

export type AuditEvent = {
  id: number;
  actorUserId: number | null;
  actorName: string | null;
  action: string;
  resourceType: string;
  resourceId: string | null;
  outcome: "success" | "failure";
  requestId: string | null;
  metadata: string | null;
  createdAt: string;
};

async function restRequest<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`/api/rest/v1${path}`, {
    ...init,
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
      ...init?.headers,
    },
  });

  if (!response.ok) {
    const payload = (await response.json().catch(() => null)) as RestError | null;
    throw new Error(payload?.error.message ?? `Falha HTTP ${response.status}`);
  }

  if (response.status === 204) return undefined as T;
  return response.json() as Promise<T>;
}

export const restApi = {
  health: () => restRequest<{ status: string; service: string; version: string }>("/health"),
  audit: (params?: { action?: string; limit?: number }) => {
    const query = new URLSearchParams();
    if (params?.action) query.set("action", params.action);
    query.set("limit", String(params?.limit ?? 50));
    return restRequest<{ data: AuditEvent[]; count: number; requestId: string }>(
      `/auditoria?${query.toString()}`
    );
  },
};
