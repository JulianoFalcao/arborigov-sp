import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import DashboardLayout from "./components/DashboardLayout";
import CitizenDashboard from "./pages/CitizenDashboard";
import ManagerDashboard from "./pages/ManagerDashboard";
import AuditDashboard from "./pages/AuditDashboard";

function DashboardPage() {
  return (
    <DashboardLayout>
      <CitizenDashboard />
    </DashboardLayout>
  );
}

function ManagerPage() {
  return (
    <DashboardLayout>
      <ManagerDashboard />
    </DashboardLayout>
  );
}

function AuditPage() {
  return (
    <DashboardLayout>
      <AuditDashboard />
    </DashboardLayout>
  );
}

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/dashboard"} component={DashboardPage} />
      <Route path={"/gestor"} component={ManagerPage} />
      <Route path={"/auditoria"} component={AuditPage} />
      <Route path={"/404"} component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
