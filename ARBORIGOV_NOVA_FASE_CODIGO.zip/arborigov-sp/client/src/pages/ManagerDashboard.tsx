import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { toast } from "sonner";
import {
  TreePine,
  MapPin,
  Clock,
  AlertTriangle,
  CheckCircle2,
  Search,
  Truck,
  BarChart3,
  TrendingUp,
  Users,
  Zap,
  MessageCircle,
} from "lucide-react";
import { useState, useMemo } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";

const statusConfig: Record<string, { label: string; color: string; icon: React.ElementType }> = {
  aberto: { label: "Aberto", color: "bg-yellow-100 text-yellow-800 border-yellow-300", icon: Clock },
  em_analise: { label: "Em Análise", color: "bg-blue-100 text-blue-800 border-blue-300", icon: Search },
  equipe_deslocamento: { label: "Equipe em Deslocamento", color: "bg-orange-100 text-orange-800 border-orange-300", icon: Truck },
  concluido: { label: "Concluído", color: "bg-green-100 text-green-800 border-green-300", icon: CheckCircle2 },
};

const PIE_COLORS = ["#22c55e", "#3b82f6", "#f59e0b", "#ef4444"];

export default function ManagerDashboard() {
  const allChamados = trpc.chamado.listAll.useQuery();
  const statsBySubprefeitura = trpc.stats.bySubprefeitura.useQuery();
  const statsByStatus = trpc.stats.byStatus.useQuery();
  const statsByTipo = trpc.stats.byTipo.useQuery();
  const statisticalSummary = trpc.stats.summary.useQuery();
  const priorityTop = trpc.stats.priorityTop.useQuery();

  const [selectedChamado, setSelectedChamado] = useState<number | null>(null);
  const [newStatus, setNewStatus] = useState("");
  const [observacao, setObservacao] = useState("");
  const [gutG, setGutG] = useState(3);
  const [gutU, setGutU] = useState(3);
  const [gutT, setGutT] = useState(3);
  const [obsGestor, setObsGestor] = useState("");

  const updateStatusMutation = trpc.chamado.updateStatus.useMutation({
    onSuccess: () => {
      toast.success("Status atualizado!");
      allChamados.refetch();
      priorityTop.refetch();
      setSelectedChamado(null);
    },
    onError: (err) => toast.error(err.message),
  });

  const updateGUTMutation = trpc.chamado.updateGUT.useMutation({
    onSuccess: () => {
      toast.success("Priorização GUT atualizada!");
      allChamados.refetch();
      priorityTop.refetch();
      setSelectedChamado(null);
    },
    onError: (err) => toast.error(err.message),
  });

  const chamados = allChamados.data ?? [];
  const totalChamados = chamados.length;
  const urgentes = chamados.filter((c) => c.chamado.tipo === "urgente").length;
  const pendentes = chamados.filter((c) => c.chamado.status !== "concluido").length;
  const concluidos = chamados.filter((c) => c.chamado.status === "concluido").length;
  const summary = statisticalSummary.data;

  const barData = useMemo(() => {
    return (statsBySubprefeitura.data ?? []).map((s) => ({
      name: (s.subprefeitura ?? "Sem info").length > 12
        ? (s.subprefeitura ?? "Sem info").substring(0, 12) + "…"
        : s.subprefeitura ?? "Sem info",
      total: Number(s.total),
      abertos: Number(s.abertos),
      concluidos: Number(s.concluidos),
    }));
  }, [statsBySubprefeitura.data]);

  const pieData = useMemo(() => {
    return (statsByStatus.data ?? []).map((s) => ({
      name: statusConfig[s.status]?.label ?? s.status,
      value: Number(s.total),
    }));
  }, [statsByStatus.data]);

  const openDetail = (chamadoId: number) => {
    const found = chamados.find((c) => c.chamado.id === chamadoId);
    if (found) {
      setSelectedChamado(chamadoId);
      setNewStatus(found.chamado.status);
      setGutG(found.chamado.gravidade);
      setGutU(found.chamado.urgencia);
      setGutT(found.chamado.tendencia);
      setObsGestor(found.chamado.observacoesGestor ?? "");
      setObservacao("");
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Painel do Gestor</h1>
        <p className="text-muted-foreground">Visão geral dos chamados e priorização por Matriz GUT</p>
      </div>

      {/* WhatsApp Notification Placeholder */}
      <Card className="border-amber-200 bg-amber-50">
        <CardContent className="pt-5 pb-4 px-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-amber-900 font-medium">Integração com WhatsApp</p>
              <p className="text-xs text-amber-700 mt-1">Notificações em breve</p>
            </div>
            <Button
              size="sm"
              variant="outline"
              className="border-amber-300 hover:bg-amber-100"
              onClick={() => toast.info("Integração com WhatsApp em breve! Notificações automáticas para equipes em campo.")}
            >
              <MessageCircle className="h-4 w-4 mr-2" />
              Saiba mais
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-5 pb-4 px-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total</p>
                <p className="text-2xl font-bold">{totalChamados}</p>
              </div>
              <TreePine className="h-8 w-8 text-primary/30" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5 pb-4 px-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Urgentes</p>
                <p className="text-2xl font-bold text-red-600">{urgentes}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-500/30" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5 pb-4 px-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Pendentes</p>
                <p className="text-2xl font-bold text-yellow-600">{pendentes}</p>
              </div>
              <Clock className="h-8 w-8 text-yellow-500/30" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5 pb-4 px-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Concluídos</p>
                <p className="text-2xl font-bold text-green-600">{concluidos}</p>
              </div>
              <CheckCircle2 className="h-8 w-8 text-green-500/30" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Statistical analysis */}
      <Card className="overflow-hidden border-primary/15">
        <CardHeader className="bg-primary/[0.04]">
          <CardTitle className="flex items-center gap-2 text-base">
            <TrendingUp className="h-5 w-5 text-primary" />
            Leitura estatística para decisão pública
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-5 pt-5">
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <div className="rounded-xl bg-muted/60 p-4">
              <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">GUT médio</p>
              <p className="mt-1 text-2xl font-bold">{summary?.meanGut ?? "—"}</p>
              <p className="text-xs text-muted-foreground">Intensidade média dos riscos</p>
            </div>
            <div className="rounded-xl bg-muted/60 p-4">
              <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Mediana GUT</p>
              <p className="mt-1 text-2xl font-bold">{summary?.medianGut ?? "—"}</p>
              <p className="text-xs text-muted-foreground">Centro da distribuição</p>
            </div>
            <div className="rounded-xl bg-muted/60 p-4">
              <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Desvio-padrão</p>
              <p className="mt-1 text-2xl font-bold">{summary?.standardDeviationGut ?? "—"}</p>
              <p className="text-xs text-muted-foreground">Dispersão dos níveis de risco</p>
            </div>
            <div className="rounded-xl bg-muted/60 p-4">
              <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Taxa de resolução</p>
              <p className="mt-1 text-2xl font-bold text-primary">{summary ? `${summary.resolutionRatePct}%` : "—"}</p>
              <p className="text-xs text-muted-foreground">Chamados concluídos sobre o total</p>
            </div>
          </div>

          <div className="rounded-xl border border-dashed border-primary/25 bg-primary/[0.03] p-4 text-sm leading-relaxed text-muted-foreground">
            <span className="font-semibold text-foreground">Interpretação gerencial: </span>
            {summary && summary.total > 0
              ? `A base contém ${summary.total} chamados, dos quais ${summary.resolved} foram concluídos. ` +
                `A média GUT é ${summary.meanGut} e a mediana é ${summary.medianGut}. ` +
                (summary.standardDeviationGut > summary.meanGut * 0.75
                  ? "A dispersão elevada indica coexistência de ocorrências simples e casos muito críticos; recomenda-se preservar a fila de prioridade. "
                  : "A dispersão controlada indica níveis de risco relativamente próximos na carteira atual. ") +
                (summary.averageResolutionHours !== null
                  ? `O tempo médio de resolução observado é de ${summary.averageResolutionHours} horas.`
                  : "Ainda não há dados de tempo de resolução suficientes para calcular a média.")
              : "Os indicadores serão calculados automaticamente quando houver chamados registrados."}
          </div>
        </CardContent>
      </Card>

      {/* Charts */}
      <div className="grid lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <BarChart3 className="h-5 w-5 text-primary" />
              Chamados por Subprefeitura
            </CardTitle>
          </CardHeader>
          <CardContent>
            {barData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={barData} margin={{ top: 5, right: 10, left: -10, bottom: 60 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="name" angle={-45} textAnchor="end" fontSize={11} tick={{ fill: "hsl(var(--muted-foreground))" }} />
                  <YAxis fontSize={12} tick={{ fill: "hsl(var(--muted-foreground))" }} />
                  <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "8px" }} />
                  <Bar dataKey="total" fill="hsl(var(--chart-1))" radius={[4, 4, 0, 0]} name="Total" />
                  <Bar dataKey="concluidos" fill="hsl(var(--chart-2))" radius={[4, 4, 0, 0]} name="Concluídos" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                Sem dados disponíveis
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <TrendingUp className="h-5 w-5 text-secondary" />
              Distribuição por Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            {pieData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie data={pieData} cx="50%" cy="50%" innerRadius={60} outerRadius={100} paddingAngle={4} dataKey="value" label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`} labelLine={false} fontSize={11}>
                    {pieData.map((_, i) => (
                      <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                Sem dados disponíveis
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Chamados Table */}
      <Card className="border-primary/20">
        <CardHeader><CardTitle className="flex items-center gap-2 text-base"><Zap className="h-5 w-5 text-primary" /> Fila de prioridade — cinco chamados pendentes</CardTitle></CardHeader>
        <CardContent>
          {priorityTop.isLoading ? <p className="text-sm text-muted-foreground">Calculando prioridades…</p> :
            priorityTop.data?.length ? (
              <ol className="grid gap-2 sm:grid-cols-2 lg:grid-cols-5">
                {priorityTop.data.map((item, index) => (
                  <li key={item.id} className="rounded-lg border p-3 text-sm">
                    <p className="text-xs text-muted-foreground">{index + 1}º na fila</p>
                    <p className="font-semibold">Chamado #{item.id} · GUT {item.gutScore}</p>
                    <p className="text-xs text-muted-foreground">{item.subprefeitura ?? "Região não informada"}</p>
                    <Button size="sm" variant="outline" className="mt-2 bg-transparent" onClick={() => openDetail(item.id)}>Gerenciar</Button>
                  </li>
                ))}
              </ol>
            ) : <p className="text-sm text-muted-foreground">Nenhum chamado pendente.</p>}
        </CardContent>
      </Card>

      {/* Chamados Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Users className="h-5 w-5 text-primary" />
            Todos os Chamados (Prioridade GUT)
          </CardTitle>
        </CardHeader>
        <CardContent>
          {allChamados.isLoading ? (
            <div className="animate-pulse space-y-3">
              {[1, 2, 3].map((i) => <div key={i} className="h-16 bg-muted rounded-lg" />)}
            </div>
          ) : chamados.length === 0 ? (
            <div className="py-12 text-center text-muted-foreground">
              <TreePine className="h-10 w-10 mx-auto mb-3 opacity-30" />
              Nenhum chamado registrado
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-left">
                    <th className="pb-3 font-medium text-muted-foreground">#</th>
                    <th className="pb-3 font-medium text-muted-foreground">Tipo</th>
                    <th className="pb-3 font-medium text-muted-foreground hidden md:table-cell">Cidadão</th>
                    <th className="pb-3 font-medium text-muted-foreground">Endereço</th>
                    <th className="pb-3 font-medium text-muted-foreground hidden lg:table-cell">Subprefeitura</th>
                    <th className="pb-3 font-medium text-muted-foreground">GUT</th>
                    <th className="pb-3 font-medium text-muted-foreground">Status</th>
                    <th className="pb-3 font-medium text-muted-foreground">Ação</th>
                  </tr>
                </thead>
                <tbody>
                  {chamados.map(({ chamado: c, userName }) => {
                    const st = statusConfig[c.status] ?? statusConfig.aberto;
                    const StIcon = st.icon;
                    return (
                      <tr key={c.id} className="border-b last:border-0 hover:bg-muted/50 transition-colors">
                        <td className="py-3 font-medium">{c.id}</td>
                        <td className="py-3">
                          <Badge variant="outline" className={`text-xs ${c.tipo === "urgente" ? "border-red-300 text-red-700" : "border-primary/30 text-primary"}`}>
                            {c.tipo === "urgente" ? "Urgente" : "Preventivo"}
                          </Badge>
                        </td>
                        <td className="py-3 hidden md:table-cell text-muted-foreground">{userName ?? "—"}</td>
                        <td className="py-3 max-w-[200px] truncate">{c.endereco}</td>
                        <td className="py-3 hidden lg:table-cell text-muted-foreground">{c.subprefeitura ?? "—"}</td>
                        <td className="py-3">
                          <span className={`font-bold ${c.gutScore >= 64 ? "text-red-600" : c.gutScore >= 27 ? "text-yellow-600" : "text-green-600"}`}>
                            {c.gutScore}
                          </span>
                        </td>
                        <td className="py-3">
                          <Badge className={`${st.color} border gap-1 text-xs`}>
                            <StIcon className="h-3 w-3" />
                            {st.label}
                          </Badge>
                        </td>
                        <td className="py-3">
                          <Button size="sm" variant="outline" onClick={() => openDetail(c.id)} className="bg-transparent text-xs">
                            Gerenciar
                          </Button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Detail Dialog */}
      <Dialog open={selectedChamado !== null} onOpenChange={(open) => !open && setSelectedChamado(null)}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Gerenciar Chamado #{selectedChamado}</DialogTitle>
          </DialogHeader>
          {selectedChamado && (() => {
            const found = chamados.find((c) => c.chamado.id === selectedChamado);
            if (!found) return null;
            const c = found.chamado;
            return (
              <div className="space-y-5 pt-2">
                <div className="rounded-lg border p-4 space-y-2 text-sm">
                  <p><strong>Tipo:</strong> {c.tipo === "urgente" ? "Urgente" : "Preventivo"}</p>
                  <p><strong>Endereço:</strong> {c.endereco}</p>
                  <p><strong>Subprefeitura:</strong> {c.subprefeitura ?? "—"}</p>
                  <p><strong>Descrição:</strong> {c.descricao}</p>
                  <p><strong>Contato com fiação:</strong> {c.contatoFiacao === "sim" ? "Sim" : "Não"}</p>
                  <div className="rounded-lg border border-primary/20 bg-primary/5 p-3">
                    <p className="font-semibold flex items-center gap-2"><Zap className="h-4 w-4 text-primary" /> Triagem visual assistida por IA</p>
                    {c.iaAnalisadoEm ? (
                      <>
                        <p><strong>Saúde:</strong> {c.iaSaude} · <strong>Risco de queda:</strong> {c.iaRiscoQueda}</p>
                        <p><strong>Confiança estimada:</strong> {Math.round(Number(c.iaConfianca) * 100)}% · <strong>Análise:</strong> {new Date(c.iaAnalisadoEm).toLocaleString("pt-BR")}</p>
                        <p className="text-xs text-muted-foreground">{Number(c.iaConfianca) < 0.6 ? "Confiança baixa: a IA não influenciou o GUT." : "Sugestão considerada no GUT inicial; confirme em vistoria técnica."}</p>
                      </>
                    ) : <p className="text-xs text-muted-foreground">Chamado sem análise de IA atestada.</p>}
                  </div>
                  {c.fotoUrl && (
                    <div className="flex gap-2 flex-wrap pt-2">
                      <img src={c.fotoUrl} alt="Foto 1" className="h-20 w-20 rounded-lg object-cover border" />
                      {c.fotoUrl2 && <img src={c.fotoUrl2} alt="Foto 2" className="h-20 w-20 rounded-lg object-cover border" />}
                      {c.fotoUrl3 && <img src={c.fotoUrl3} alt="Foto 3" className="h-20 w-20 rounded-lg object-cover border" />}
                    </div>
                  )}
                </div>

                {/* Status Update */}
                <div className="space-y-2">
                  <Label>Atualizar Status</Label>
                  <Select value={newStatus} onValueChange={setNewStatus}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="aberto">Aberto</SelectItem>
                      <SelectItem value="em_analise">Em Análise</SelectItem>
                      <SelectItem value="equipe_deslocamento">Equipe em Deslocamento</SelectItem>
                      <SelectItem value="concluido">Concluído</SelectItem>
                    </SelectContent>
                  </Select>
                  <Textarea placeholder="Observação (opcional)" value={observacao} onChange={(e) => setObservacao(e.target.value)} rows={2} />
                  <Button
                    onClick={() => updateStatusMutation.mutate({ chamadoId: selectedChamado, status: newStatus as any, observacao: observacao || undefined })}
                    disabled={updateStatusMutation.isPending}
                    className="w-full"
                  >
                    {updateStatusMutation.isPending ? "Atualizando..." : "Atualizar Status"}
                  </Button>
                </div>

                {/* GUT Matrix */}
                <div className="space-y-4 rounded-lg border p-4">
                  <h4 className="font-semibold flex items-center gap-2">
                    <Zap className="h-4 w-4 text-primary" />
                    Matriz GUT (Score: {gutG * gutU * gutT})
                  </h4>
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Gravidade</span>
                        <span className="font-medium">{gutG}</span>
                      </div>
                      <Slider value={[gutG]} onValueChange={([v]) => setGutG(v)} min={1} max={5} step={1} />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Urgência</span>
                        <span className="font-medium">{gutU}</span>
                      </div>
                      <Slider value={[gutU]} onValueChange={([v]) => setGutU(v)} min={1} max={5} step={1} />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Tendência</span>
                        <span className="font-medium">{gutT}</span>
                      </div>
                      <Slider value={[gutT]} onValueChange={([v]) => setGutT(v)} min={1} max={5} step={1} />
                    </div>
                  </div>
                  <Textarea placeholder="Observações do gestor" value={obsGestor} onChange={(e) => setObsGestor(e.target.value)} rows={2} />
                  <Button
                    variant="outline"
                    onClick={() => updateGUTMutation.mutate({ chamadoId: selectedChamado, gravidade: gutG, urgencia: gutU, tendencia: gutT, observacoesGestor: obsGestor || undefined })}
                    disabled={updateGUTMutation.isPending}
                    className="w-full bg-transparent"
                  >
                    {updateGUTMutation.isPending ? "Salvando..." : "Salvar Priorização GUT"}
                  </Button>
                </div>
              </div>
            );
          })()}
        </DialogContent>
      </Dialog>
    </div>
  );
}
