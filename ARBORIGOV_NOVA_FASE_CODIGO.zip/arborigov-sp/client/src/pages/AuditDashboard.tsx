import { useAuth } from "@/_core/hooks/useAuth";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { type AuditEvent, restApi } from "@/lib/rest";
import { AlertTriangle, CheckCircle2, DatabaseZap, RefreshCw, ShieldCheck } from "lucide-react";
import { useCallback, useEffect, useState } from "react";

const ACTION_LABELS: Record<string, string> = {
  CHAMADO_CREATED: "Chamado criado",
  CHAMADO_UPDATED: "Chamado atualizado",
  CHAMADO_DELETED: "Chamado excluído",
  CHAMADO_STATUS_CHANGED: "Status alterado",
  CHAMADO_GUT_CHANGED: "GUT alterado",
  SENSITIVE_RECORD_VIEWED: "Consulta sensível",
  REPORT_EXPORTED: "Relatório exportado",
};

function formatDate(value: string) {
  return new Date(value).toLocaleString("pt-BR", {
    dateStyle: "short",
    timeStyle: "medium",
  });
}

export default function AuditDashboard() {
  const { user } = useAuth();
  const [events, setEvents] = useState<AuditEvent[]>([]);
  const [serviceStatus, setServiceStatus] = useState<"checking" | "online" | "offline">("checking");
  const [action, setAction] = useState("all");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [health, audit] = await Promise.all([
        restApi.health(),
        restApi.audit({ action: action === "all" ? undefined : action, limit: 50 }),
      ]);
      setServiceStatus(health.status === "ok" ? "online" : "offline");
      setEvents(audit.data);
    } catch (cause) {
      setServiceStatus("offline");
      setError(cause instanceof Error ? cause.message : "Não foi possível consultar a auditoria");
    } finally {
      setLoading(false);
    }
  }, [action]);

  useEffect(() => {
    if (user?.role === "admin") void loadData();
  }, [loadData, user?.role]);

  if (user?.role !== "admin") {
    return (
      <Alert variant="destructive">
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>Acesso restrito</AlertTitle>
        <AlertDescription>Somente gestores autorizados podem consultar a trilha de auditoria.</AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-sm font-medium uppercase tracking-[0.18em] text-primary">Governança</p>
          <h1 className="mt-1 text-2xl font-bold text-foreground">Trilha de auditoria</h1>
          <p className="text-muted-foreground">
            Evidências de operações críticas consumidas diretamente pela API RESTful.
          </p>
        </div>
        <Button onClick={() => void loadData()} disabled={loading} variant="outline" className="bg-card">
          <RefreshCw className={`mr-2 h-4 w-4 ${loading ? "animate-spin" : ""}`} />
          Atualizar
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="md:col-span-2">
          <CardHeader className="pb-3">
            <CardDescription>Eventos retornados</CardDescription>
            <CardTitle className="text-3xl">{events.length}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardDescription>API REST v1</CardDescription>
            <div className="flex items-center gap-2">
              <DatabaseZap className="h-5 w-5 text-primary" />
              <CardTitle className="text-lg">
                {serviceStatus === "online" ? "Operacional" : serviceStatus === "offline" ? "Indisponível" : "Verificando"}
              </CardTitle>
            </div>
          </CardHeader>
        </Card>
      </div>

      <Card>
        <CardHeader className="gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <ShieldCheck className="h-5 w-5 text-primary" />
              Eventos auditáveis
            </CardTitle>
            <CardDescription>A lista é limitada a 50 registros e não exibe segredos nem arquivos brutos.</CardDescription>
          </div>
          <Select value={action} onValueChange={setAction}>
            <SelectTrigger className="w-full bg-background sm:w-56" aria-label="Filtrar por ação">
              <SelectValue placeholder="Todas as ações" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas as ações</SelectItem>
              {Object.entries(ACTION_LABELS).map(([value, label]) => (
                <SelectItem key={value} value={value}>{label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardHeader>
        <CardContent>
          {error ? (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Falha na consulta REST</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          ) : events.length === 0 && !loading ? (
            <div className="rounded-xl border border-dashed p-10 text-center text-muted-foreground">
              Nenhum evento corresponde ao filtro selecionado.
            </div>
          ) : (
            <div className="overflow-x-auto rounded-xl border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Data e hora</TableHead>
                    <TableHead>Ação</TableHead>
                    <TableHead>Ator</TableHead>
                    <TableHead>Recurso</TableHead>
                    <TableHead>Resultado</TableHead>
                    <TableHead>Request ID</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {events.map(event => (
                    <TableRow key={event.id}>
                      <TableCell className="whitespace-nowrap text-sm">{formatDate(event.createdAt)}</TableCell>
                      <TableCell className="font-medium">{ACTION_LABELS[event.action] ?? event.action}</TableCell>
                      <TableCell>{event.actorName ?? `Usuário ${event.actorUserId ?? "sistema"}`}</TableCell>
                      <TableCell>{event.resourceType} {event.resourceId ? `#${event.resourceId}` : ""}</TableCell>
                      <TableCell>
                        <Badge variant={event.outcome === "success" ? "default" : "destructive"}>
                          {event.outcome === "success" ? (
                            <CheckCircle2 className="mr-1 h-3 w-3" />
                          ) : (
                            <AlertTriangle className="mr-1 h-3 w-3" />
                          )}
                          {event.outcome === "success" ? "Sucesso" : "Falha"}
                        </Badge>
                      </TableCell>
                      <TableCell className="max-w-40 truncate font-mono text-xs text-muted-foreground">
                        {event.requestId ?? "—"}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
