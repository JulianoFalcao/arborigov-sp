import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import {
  Plus,
  TreePine,
  MapPin,
  Clock,
  AlertTriangle,
  CheckCircle2,
  Truck,
  Search,
  Camera,
  Zap,
  BrainCircuit,
  Loader2,
  ShieldCheck,
} from "lucide-react";
import { useState, useRef, useCallback } from "react";

const SUBPREFEITURAS = [
  "Aricanduva/Formosa/Carrão",
  "Butantã",
  "Campo Limpo",
  "Capela do Socorro",
  "Casa Verde/Cachoeirinha",
  "Cidade Ademar",
  "Cidade Tiradentes",
  "Ermelino Matarazzo",
  "Freguesia/Brasilândia",
  "Guaianases",
  "Ipiranga",
  "Itaim Paulista",
  "Itaquera",
  "Jabaquara",
  "Jaçanã/Tremembé",
  "Lapa",
  "M'Boi Mirim",
  "Mooca",
  "Parelheiros",
  "Penha",
  "Perus",
  "Pinheiros",
  "Pirituba/Jaraguá",
  "Santana/Tucuruvi",
  "Santo Amaro",
  "São Mateus",
  "São Miguel Paulista",
  "Sapopemba",
  "Sé",
  "Vila Maria/Vila Guilherme",
  "Vila Mariana",
  "Vila Prudente",
];

const statusConfig: Record<string, { label: string; color: string; icon: React.ElementType }> = {
  aberto: { label: "Aberto", color: "bg-yellow-100 text-yellow-800 border-yellow-300", icon: Clock },
  em_analise: { label: "Em Análise", color: "bg-blue-100 text-blue-800 border-blue-300", icon: Search },
  equipe_deslocamento: { label: "Equipe em Deslocamento", color: "bg-orange-100 text-orange-800 border-orange-300", icon: Truck },
  concluido: { label: "Concluído", color: "bg-green-100 text-green-800 border-green-300", icon: CheckCircle2 },
};

type TreeAnalysis = {
  saude_geral: "crítica" | "ruim" | "regular" | "boa" | "excelente";
  doencas_detectadas: string[];
  danos_estruturais: string[];
  risco_queda: "baixo" | "médio" | "alto" | "crítico";
  confianca: number;
  recomendacoes: string[];
  iaAttestation: string;
};

const MAX_IMAGE_SIZE = 5 * 1024 * 1024;
const ACCEPTED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp"];

export default function CitizenDashboard() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [tipo, setTipo] = useState<"preventivo" | "urgente">("preventivo");
  const [descricao, setDescricao] = useState("");
  const [endereco, setEndereco] = useState("");
  const [subprefeitura, setSubprefeitura] = useState("");
  const [contatoFiacao, setContatoFiacao] = useState(false);
  const [photos, setPhotos] = useState<string[]>([]);
  const [latitude, setLatitude] = useState("");
  const [longitude, setLongitude] = useState("");
  const [iaAnalysis, setIaAnalysis] = useState<TreeAnalysis | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const myList = trpc.chamado.myList.useQuery();
  const createMutation = trpc.chamado.create.useMutation({
    onSuccess: () => {
      toast.success("Chamado criado com sucesso!");
      setDialogOpen(false);
      resetForm();
      myList.refetch();
    },
    onError: (err) => toast.error(err.message),
  });
  const analyzeMutation = trpc.chamado.analyzeImage.useMutation({
    onSuccess: (data) => {
      setIaAnalysis(data as TreeAnalysis);
      toast.success("Triagem por IA concluída. Revise o diagnóstico antes de enviar.");
    },
    onError: (err) => toast.error(err.message),
  });

  const resetForm = () => {
    setTipo("preventivo");
    setDescricao("");
    setEndereco("");
    setSubprefeitura("");
    setContatoFiacao(false);
    setPhotos([]);
    setLatitude("");
    setLongitude("");
    setIaAnalysis(null);
  };

  const handleGetLocation = useCallback(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setLatitude(pos.coords.latitude.toFixed(7));
          setLongitude(pos.coords.longitude.toFixed(7));
          toast.success("Localização capturada!");
        },
        () => toast.error("Não foi possível obter a localização.")
      );
    } else {
      toast.error("Geolocalização não suportada pelo navegador.");
    }
  }, []);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    const selected = Array.from(files).slice(0, 3 - photos.length);
    const invalidType = selected.find(file => !ACCEPTED_IMAGE_TYPES.includes(file.type));
    const oversized = selected.find(file => file.size > MAX_IMAGE_SIZE);
    if (invalidType) {
      toast.error("Formato não permitido. Use JPG, PNG ou WebP.");
      e.target.value = "";
      return;
    }
    if (oversized) {
      toast.error("Cada imagem deve ter no máximo 5 MB.");
      e.target.value = "";
      return;
    }
    setIaAnalysis(null);
    selected.forEach((file) => {
      const reader = new FileReader();
      reader.onload = () => {
        if (reader.result) {
          setPhotos((prev) => [...prev.slice(0, 2), reader.result as string]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleAnalyzeImage = () => {
    if (!photos[0]) {
      toast.error("Adicione ao menos uma foto para executar a triagem por IA.");
      return;
    }
    analyzeMutation.mutate({ fotoBase64: photos[0] });
  };

  const handleSubmit = () => {
    if (!descricao || !endereco) {
      toast.error("Preencha a descrição e o endereço.");
      return;
    }
    createMutation.mutate({
      tipo,
      descricao,
      endereco,
      subprefeitura: subprefeitura || undefined,
      latitude: latitude || undefined,
      longitude: longitude || undefined,
      contatoFiacao: contatoFiacao ? "sim" : "nao",
      fotoBase64: photos[0] || undefined,
      fotoBase64_2: photos[1] || undefined,
      fotoBase64_3: photos[2] || undefined,
      iaAttestation: iaAnalysis?.iaAttestation,
    });
  };

  const chamados = myList.data ?? [];
  const abertos = chamados.filter((c) => c.status !== "concluido").length;
  const concluidos = chamados.filter((c) => c.status === "concluido").length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Meus Chamados</h1>
          <p className="text-muted-foreground">Gerencie suas solicitações de poda e remoção de árvores</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" /> Novo Chamado
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <TreePine className="h-5 w-5 text-primary" />
                Novo Chamado de Poda/Remoção
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-2">
              {/* Tipo */}
              <div className="space-y-2">
                <Label>Tipo do Chamado</Label>
                <Select value={tipo} onValueChange={(v) => setTipo(v as "preventivo" | "urgente")}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="preventivo">
                      <span className="flex items-center gap-2">
                        <TreePine className="h-4 w-4 text-primary" /> Preventivo (risco identificado)
                      </span>
                    </SelectItem>
                    <SelectItem value="urgente">
                      <span className="flex items-center gap-2">
                        <AlertTriangle className="h-4 w-4 text-destructive" /> Urgente (queda ocorrida)
                      </span>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Descrição */}
              <div className="space-y-2">
                <Label>Descrição do Problema</Label>
                <Textarea
                  placeholder="Descreva o problema observado com a árvore..."
                  value={descricao}
                  onChange={(e) => setDescricao(e.target.value)}
                  rows={3}
                />
              </div>

              {/* Endereço */}
              <div className="space-y-2">
                <Label>Endereço</Label>
                <Input
                  placeholder="Rua, número, bairro..."
                  value={endereco}
                  onChange={(e) => setEndereco(e.target.value)}
                />
              </div>

              {/* Subprefeitura */}
              <div className="space-y-2">
                <Label>Subprefeitura</Label>
                <Select value={subprefeitura} onValueChange={setSubprefeitura}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione a subprefeitura" />
                  </SelectTrigger>
                  <SelectContent>
                    {SUBPREFEITURAS.map((sp) => (
                      <SelectItem key={sp} value={sp}>{sp}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Geolocalização */}
              <div className="space-y-2">
                <Label>Geolocalização</Label>
                <div className="flex gap-2">
                  <Input placeholder="Latitude" value={latitude} onChange={(e) => setLatitude(e.target.value)} className="flex-1" />
                  <Input placeholder="Longitude" value={longitude} onChange={(e) => setLongitude(e.target.value)} className="flex-1" />
                  <Button type="button" variant="outline" size="icon" onClick={handleGetLocation} className="shrink-0 bg-transparent">
                    <MapPin className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">Clique no ícone para capturar automaticamente</p>
              </div>

              {/* Contato com fiação */}
              <div className="flex items-center justify-between rounded-lg border p-3">
                <div className="space-y-0.5">
                  <Label className="flex items-center gap-2">
                    <Zap className="h-4 w-4 text-yellow-500" />
                    Contato com Fiação Elétrica
                  </Label>
                  <p className="text-xs text-muted-foreground">A árvore está em contato com fios de energia?</p>
                </div>
                <Switch checked={contatoFiacao} onCheckedChange={setContatoFiacao} />
              </div>

              {/* Fotos */}
              <div className="space-y-2">
                <Label>Fotos (até 3)</Label>
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  multiple
                  className="hidden"
                  onChange={handlePhotoUpload}
                />
                <div className="flex gap-2 flex-wrap">
                  {photos.map((p, i) => (
                    <div key={i} className="h-20 w-20 rounded-lg overflow-hidden border">
                      <img src={p} alt={`Foto ${i + 1}`} className="h-full w-full object-cover" />
                    </div>
                  ))}
                  {photos.length < 3 && (
                    <button
                      onClick={() => fileRef.current?.click()}
                      className="h-20 w-20 rounded-lg border-2 border-dashed border-muted-foreground/30 flex items-center justify-center hover:border-primary/50 transition-colors"
                    >
                      <Camera className="h-6 w-6 text-muted-foreground" />
                    </button>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">JPG, PNG ou WebP, com até 5 MB por arquivo.</p>
              </div>

              <div className="rounded-xl border border-primary/20 bg-primary/5 p-4">
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <p className="flex items-center gap-2 font-semibold text-foreground">
                      <BrainCircuit className="h-4 w-4 text-primary" />
                      Triagem assistida por IA
                    </p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      Resultado indicativo para apoiar a priorização; não substitui vistoria técnica.
                    </p>
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    className="shrink-0 bg-background"
                    onClick={handleAnalyzeImage}
                    disabled={!photos[0] || analyzeMutation.isPending}
                  >
                    {analyzeMutation.isPending ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <BrainCircuit className="mr-2 h-4 w-4" />
                    )}
                    {analyzeMutation.isPending ? "Analisando..." : "Analisar foto"}
                  </Button>
                </div>

                {iaAnalysis ? (
                  <div className="mt-4 grid gap-3 border-t border-primary/15 pt-4 sm:grid-cols-2">
                    <div>
                      <p className="text-xs uppercase tracking-wide text-muted-foreground">Saúde geral</p>
                      <p className="font-semibold capitalize">{iaAnalysis.saude_geral}</p>
                    </div>
                    <div>
                      <p className="text-xs uppercase tracking-wide text-muted-foreground">Risco de queda</p>
                      <p className="font-semibold capitalize">{iaAnalysis.risco_queda}</p>
                    </div>
                    <div>
                      <p className="text-xs uppercase tracking-wide text-muted-foreground">Confiança estimada</p>
                      <p className="font-semibold">{Math.round(iaAnalysis.confianca * 100)}%</p>
                      {iaAnalysis.confianca < 0.6 && <p className="text-xs text-amber-700">Abaixo de 60%: a IA não altera a prioridade GUT.</p>}
                    </div>
                    <div>
                      <p className="text-xs uppercase tracking-wide text-muted-foreground">Recomendações</p>
                      <p className="text-sm">{iaAnalysis.recomendacoes.join(", ") || "Vistoria técnica"}</p>
                    </div>
                    <div className="sm:col-span-2 flex items-start gap-2 rounded-lg bg-background/80 p-3 text-xs text-muted-foreground">
                      <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                      A imagem é processada para triagem e o chamado permanece sujeito à validação de um gestor público.
                    </div>
                  </div>
                ) : null}
              </div>

              <Button onClick={handleSubmit} className="w-full" disabled={createMutation.isPending}>
                {createMutation.isPending ? "Enviando..." : "Enviar Chamado"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-5 pb-4 px-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total</p>
                <p className="text-2xl font-bold">{chamados.length}</p>
              </div>
              <TreePine className="h-8 w-8 text-primary/30" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5 pb-4 px-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Em Andamento</p>
                <p className="text-2xl font-bold text-yellow-600">{abertos}</p>
              </div>
              <Clock className="h-8 w-8 text-yellow-500/30" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5 pb-4 px-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Concluídos</p>
                <p className="text-2xl font-bold text-green-600">{concluidos}</p>
              </div>
              <CheckCircle2 className="h-8 w-8 text-green-500/30" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Chamados List */}
      {myList.isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="h-24 pt-6" />
            </Card>
          ))}
        </div>
      ) : chamados.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center">
            <TreePine className="h-12 w-12 mx-auto text-muted-foreground/30 mb-4" />
            <h3 className="text-lg font-medium text-foreground">Nenhum chamado ainda</h3>
            <p className="text-muted-foreground mt-1">Clique em "Novo Chamado" para reportar uma árvore com risco.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {chamados.map((c) => {
            const st = statusConfig[c.status] ?? statusConfig.aberto;
            const StIcon = st.icon;
            return (
              <Card key={c.id} className="hover:shadow-md transition-shadow">
                <CardContent className="pt-5 pb-4 px-5">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-start gap-3 flex-1">
                      <div className={`h-10 w-10 rounded-lg flex items-center justify-center shrink-0 ${c.tipo === "urgente" ? "bg-red-100" : "bg-primary/10"}`}>
                        {c.tipo === "urgente" ? (
                          <AlertTriangle className="h-5 w-5 text-red-600" />
                        ) : (
                          <TreePine className="h-5 w-5 text-primary" />
                        )}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-medium text-foreground">#{c.id}</span>
                          <Badge variant="outline" className={`text-xs ${c.tipo === "urgente" ? "border-red-300 text-red-700" : "border-primary/30 text-primary"}`}>
                            {c.tipo === "urgente" ? "Urgente" : "Preventivo"}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mt-0.5 truncate">{c.descricao}</p>
                        <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                          <MapPin className="h-3 w-3" /> {c.endereco}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={`${st.color} border gap-1`}>
                        <StIcon className="h-3 w-3" />
                        {st.label}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
