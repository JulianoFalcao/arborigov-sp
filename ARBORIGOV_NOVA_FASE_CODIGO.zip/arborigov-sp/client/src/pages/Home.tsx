import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { getLoginUrl } from "@/const";
import {
  TreePine,
  Shield,
  MapPin,
  Bell,
  BarChart3,
  Users,
  ArrowRight,
  Zap,
  Clock,
} from "lucide-react";
import { useLocation } from "wouter";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310419663029512752/bywWkV5nNqt34yhLM7Bvyz/arborigov_logo_1_5717deeb.png";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Navbar */}
      <nav className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-3">
            <img src={LOGO_URL} alt="ArboriGov SP" className="h-10 w-10" />
            <span className="text-lg font-bold text-foreground">ArboriGov <span className="text-secondary">SP</span></span>
          </div>
          <div className="flex items-center gap-3">
            {isAuthenticated ? (
              <>
                <span className="text-sm text-muted-foreground hidden sm:inline">Olá, {user?.name}</span>
                <Button onClick={() => setLocation("/dashboard")} size="sm">
                  Painel <ArrowRight className="ml-1 h-4 w-4" />
                </Button>
              </>
            ) : (
              <Button onClick={() => (window.location.href = getLoginUrl())} size="sm">
                Entrar
              </Button>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-secondary/10" />
        <div className="container relative py-20 md:py-32">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary">
                <TreePine className="h-4 w-4" />
                Zeladoria Urbana Inteligente
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-foreground leading-tight">
                Proteja sua cidade.{" "}
                <span className="text-primary">Reporte riscos</span> com um clique.
              </h1>
              <p className="text-lg text-muted-foreground max-w-lg">
                Plataforma digital que conecta cidadãos e gestores públicos para a gestão inteligente de poda e remoção de árvores em São Paulo, prevenindo quedas de energia e acidentes.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                {isAuthenticated ? (
                  <Button size="lg" onClick={() => setLocation("/dashboard")} className="gap-2">
                    Acessar Painel <ArrowRight className="h-5 w-5" />
                  </Button>
                ) : (
                  <Button size="lg" onClick={() => (window.location.href = getLoginUrl())} className="gap-2">
                    Começar Agora <ArrowRight className="h-5 w-5" />
                  </Button>
                )}
                <Button size="lg" variant="outline" onClick={() => document.getElementById("como-funciona")?.scrollIntoView({ behavior: "smooth" })} className="bg-transparent">
                  Como Funciona
                </Button>
              </div>
            </div>
            <div className="hidden md:flex justify-center">
              <div className="relative">
                <div className="absolute -inset-4 rounded-3xl bg-gradient-to-br from-primary/20 to-secondary/20 blur-2xl" />
                <img src={LOGO_URL} alt="ArboriGov SP" className="relative h-72 w-72 drop-shadow-2xl" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="border-y bg-card">
        <div className="container py-12">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { value: "REST v1", label: "Integração documentada", icon: Zap },
              { value: "43", label: "Testes automatizados", icon: Shield },
              { value: "3", label: "Perfis de acesso", icon: Users },
              { value: "1–125", label: "Escala de prioridade GUT", icon: BarChart3 },
            ].map((stat, i) => (
              <div key={i} className="text-center space-y-2">
                <stat.icon className="h-6 w-6 mx-auto text-primary" />
                <div className="text-2xl md:text-3xl font-bold text-foreground">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section id="como-funciona" className="py-20">
        <div className="container space-y-12">
          <div className="text-center space-y-4">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground">Como Funciona</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Em poucos passos, você reporta um risco e a prefeitura age com rapidez e transparência.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                step: "01",
                title: "Reporte o Risco",
                desc: "Tire uma foto da árvore, marque a localização e descreva o problema. O sistema classifica automaticamente a urgência.",
                icon: MapPin,
              },
              {
                step: "02",
                title: "Acompanhe em Tempo Real",
                desc: "Receba atualizações sobre o status do seu chamado: Aberto, Em Análise, Equipe em Deslocamento ou Concluído.",
                icon: Clock,
              },
              {
                step: "03",
                title: "Problema Resolvido",
                desc: "A equipe de zeladoria realiza a poda ou remoção. Você é notificado quando o serviço é concluído.",
                icon: Shield,
              },
            ].map((item, i) => (
              <Card key={i} className="relative overflow-hidden border-0 shadow-lg hover:shadow-xl transition-shadow">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary to-secondary" />
                <CardContent className="pt-8 pb-6 px-6 space-y-4">
                  <div className="flex items-center gap-4">
                    <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center">
                      <item.icon className="h-6 w-6 text-primary" />
                    </div>
                    <span className="text-4xl font-bold text-primary/20">{item.step}</span>
                  </div>
                  <h3 className="text-xl font-semibold text-foreground">{item.title}</h3>
                  <p className="text-muted-foreground">{item.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-card">
        <div className="container space-y-12">
          <div className="text-center space-y-4">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground">Funcionalidades</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Tecnologia a serviço da gestão pública e da segurança do cidadão.
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: MapPin, title: "Geolocalização", desc: "Localização automática via GPS para identificar exatamente onde está o risco." },
              { icon: Zap, title: "Classificação Inteligente", desc: "O sistema classifica automaticamente entre chamados Urgentes e Preventivos." },
              { icon: Bell, title: "Acompanhamento", desc: "Histórico de status para acompanhar a evolução de cada chamado." },
              { icon: BarChart3, title: "Relatórios Estatísticos", desc: "Dashboards com gráficos de desempenho por subprefeitura e período." },
              { icon: Users, title: "Painel do Gestor", desc: "Visão completa dos chamados com priorização pela Matriz GUT." },
              { icon: Shield, title: "Integração Segura", desc: "Dados protegidos conforme a LGPD com autenticação robusta." },
            ].map((feat, i) => (
              <Card key={i} className="border hover:border-primary/30 transition-colors">
                <CardContent className="pt-6 pb-5 px-6 space-y-3">
                  <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <feat.icon className="h-5 w-5 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground">{feat.title}</h3>
                  <p className="text-sm text-muted-foreground">{feat.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20">
        <div className="container">
          <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-primary to-secondary p-12 md:p-16 text-center">
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRoLTJ2LTRoMnYtNGgtNHYyaC00di0ySDIwdjRoMnY0aC0ydjRoNHYtMmg0djJoNHYtNGgtMnYtNHptMC04aDJ2LTRoLTJ2NHptLTgtOGgydi00aC0ydjR6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-20" />
            <div className="relative space-y-6">
              <h2 className="text-3xl md:text-4xl font-bold text-white">
                Sua cidade mais segura começa com você
              </h2>
              <p className="text-white/80 max-w-xl mx-auto text-lg">
                Registre ocorrências, acompanhe o status e contribua para uma gestão urbana orientada por dados.
              </p>
              {isAuthenticated ? (
                <Button size="lg" variant="secondary" onClick={() => setLocation("/dashboard")} className="gap-2 bg-white text-primary hover:bg-white/90">
                  Acessar Painel <ArrowRight className="h-5 w-5" />
                </Button>
              ) : (
                <Button size="lg" variant="secondary" onClick={() => (window.location.href = getLoginUrl())} className="gap-2 bg-white text-primary hover:bg-white/90">
                  Criar Conta Gratuita <ArrowRight className="h-5 w-5" />
                </Button>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-8 bg-card">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <img src={LOGO_URL} alt="ArboriGov SP" className="h-6 w-6" />
            <span className="text-sm font-medium text-foreground">ArboriGov SP</span>
          </div>
          <p className="text-sm text-muted-foreground">
            Projeto HackGov - Transformação Digital na Gestão Pública
          </p>
        </div>
      </footer>
    </div>
  );
}
